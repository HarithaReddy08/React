import axios from 'axios';

export default class weatherService {

    static baseURL = "https://api.openweathermap.org/data/2.5/forecast";

    // sample = "api.openweathermap.org/data/2.5/forecast?q={city name}&appid={your api key}"

    static getDetails(){

        // return axios.get("http://api.openweathermap.org/data/2.5/forecast?q=delhi,india&appid=f1cd6616ccdcfa3800aae838eaf73796")
        return axios.get(`${this.baseURL}/?q=bangalore,india&appid=f1cd6616ccdcfa3800aae838eaf73796`)

        .then(function(response){

            console.log(response.data);
            console.log(response.data.list[0].weather[0].icon);

            // console.log(response.data.list[0].main.temp);

            return response.data;
        })
        .catch(function(error){

            console.log(error.message);
            throw error;

        })
    }





}