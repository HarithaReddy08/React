import React, {Component} from 'react';
import weatherService from '../services/WeatherService'
// import Settings from './Settings';
import {Link} from 'react-router-dom';
import '../App.css'
const DETAILS_FETCHING = 'DETAILS_FETCHING';
const DETAILS_FETCHED = 'DETAILS_FETCHED';
const DETAILS_FETCH_FAILED = 'DETAILS_FETCH_FAILED';

export default class weatherDetails extends Component {

    state = {
        details : null,
        errors : null,
        day1:null,
        day2:null,
        day3:null,
        day4:null,
        day5:null

    };

    render() {       
        // console.log("weatherDetails.js");

        const {status,error,details,day1,day2,day3,day4,day5} = this.state;
       

        let el = null;

        switch(status){

            case DETAILS_FETCHING:
                el = (

                    <h1 className="har">
                        weatherDetails Fetching takes place
                    </h1>

                )
                break;

            case DETAILS_FETCHED:
                el = (



                    <div class="jumbotron">

                        <font size="8" color="blue">{details.city.name}</font>
                        <p>{Math.floor(details.list[0].main.temp - 273)}&#8451;</p>    
                        <p>{details.list[0].wind.speed} m/s</p>
                        <p>{details.list[0].main.sea_level} hpa</p>
                        <div align = 'right'>


                        <Link className="nav-link" to="/settings">
  
                        <button class="btn-btn-primary" variant="outline-primary" type = "submit">Change Location</button>
                        </Link>
                        </div>
<div  align = 'center' >

                            <h2>Predictions of next 5 days!!!!!!</h2>
                        </div>
                        <div class="form-inline">

                        



                    {
                        details.list.filter(lis=> (lis.dt_txt === day1)||(lis.dt_txt === day2)||(lis.dt_txt === day3)||(lis.dt_txt === day4)||(lis.dt_txt === day5)).map (one =>

                        <div align = 'center'>



                            <br/>
                        
                            <img src = {`http://openweathermap.org/img/wn/${one.weather[0].icon}@2x.png`} />    

                            <p>{one.dt_txt}</p>
                           <p> {Math.round(one.main.temp - 273) }&#8451; </p>

                            <p>{one.wind.speed} m/s</p>

                            <p>{one.main.sea_level} hpa</p>
                            <br/><br/>

                        </div>
                        
                        )

                        }
                            </div>
                        
                        </div>

                )
                break;

            case DETAILS_FETCH_FAILED:
                el = (

                    <h1>
                        weatherDetails Fetching Failed
                    </h1>

                )
                break;

        }

        return(
            <div> 
                <h1>Weather Details</h1>
             

                {el}

            </div>

        );
    }

    componentDidMount(){

        console.log("ComponentDidMount")

        this.setState(
            {
                status: DETAILS_FETCHING
            }
        );
if(localStorage.getItem("defaultLocation")==null)
{
    var path=weatherService.getDetails("lucknow");
}
else{
    var path=weatherService.getDetails(localStorage.getItem("defaultLocation"));
}
path
.then((details)=>
{
this.setState({
    details:details,
    status:DETAILS_FETCHED,
    day1:details.list[0].dt_txt,
    day2:details.list[8].dt_txt,
    day3:details.list[16].dt_txt,
    day4:details.list[24].dt_txt,
    day5:details.list[32].dt_txt

})
})
.catch((error=>
    {
        this.setState({
            error:error,
            details:null,
            status:DETAILS_FETCH_FAILED
        }

        )
    }))
        
    }


}

