import React from 'react';
import WeatherDetails from '../components/WeatherDetails';
import '../App.css'
function Home(props) {
    console.log("Home.js");
    return (
      <div>
        <div>
        <WeatherDetails />
        </div>
      </div>  
    );
}

export default Home;