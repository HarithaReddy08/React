import React, { Component } from 'react';
import {Link} from 'react-router-dom';
import '../index.css';


class Settings extends Component {

    state =  {

        location : [],


    }    

    addPlaceRef = React.createRef();


        add = ()=>{
        
            var noError = false;
            
            if(this.addPlaceRef.current.value.length > 2){

              
                var mp = (this.addPlaceRef.current.value).toLowerCase();
                noError=true;
            }
            if(noError)
            {
                this.storeData(mp);
                this.renderSavedLocation();
            }
        }
        Delete=()=>
        {
            if(!(localStorage.getItem("location")==null))
            {
                var deleteloc=document.getElementById("deleteLocation");
                var afterdel=deleteloc.options[deleteloc.selectedIndex].value;
                this.deleteEle(afterdel);


            }
            else{
                alert("nothing to ddelete");
            }
        }
        deleteEle=(a)=>
        {
            var delArr=localStorage.getItem("location").split(',');
            for(let i=0;i<delArr.length;i++)
            {
                if(delArr[i]===a)
                {
                    delArr.splice(i,1);
                }
            }
            localStorage.removeItem("location");
            localStorage.setItem("location",delArr);
            this.renderSavedLocation();
            if(!(localStorage.getItem("location")==null ) && (delArr.length>0))
            {
if(a==localStorage.getItem("defaultLocation"))
{
    localStorage.removeItem("defaultLocation");
            localStorage.setItem("defaultLocation",delArr[0]);
}
            }
            else{
                localStorage.removeItem("defaultLocation");
                localStorage.removeItem("location");
            }

        }
        fixDefaultLoc=(a)=>
        {
            if(localStorage.length==1)
            {
            localStorage.setItem("defaultLocation",a);
        
        }
        else{
            localStorage.removeItem("defaultLocation");
            localStorage.setItem("defaultLocation",a);
        }
        }
        set=()=>
        {
            if(!localStorage.getItem("location")==null)
            {
                var setLoc=document.getElementById("deleteLocation");
                var afterSet=setLoc.options[setLoc.selectedIndex].value;
                this.fixDefaultLoc(afterSet);


            }
            else{
                alert("running default...");
            }
        }
        notExist(arr,b)
        {
            var notPresent=true;
            var comp=arr[0].indexOf(b);
            if(comp==-1)
            {notPresent=true;
            }
            else{
                notPresent=false;
            }
            return notPresent;
        }
            

          

        storeData = (b) =>{
            if(localStorage.length==0)
            {
                var m=[b];
                console.log("localStorage is 0");
                localStorage.setItem("location",m);

            }
            else{
                var pl=[];
                var plsplit=localStorage.getItem("location").split(',');
                pl.push(plsplit);
                if(this.notExist(pl,b))
                {
                    pl.push(b);
                    localStorage.removeItem("location");
                                localStorage.setItem("location",pl);
                }
                    
                }
            }
            renderSavedLocation()
            {
                try{
                    var locArr=localStorage.getItem("location").split(',');
                    this.setState(
                        {
                            location:locArr
                        }
                    );
                }
                catch(err)
                {
                    var locArr=[];
                }
            }
                
            

        render() {
this.renderSavedLocation();
            
            

        return(

            <div className="container" align = "center">
                <form>

                <br/>
                <div className = "jumbotron">


                Saved Location     <select id = "deleteLocation">

                     {
                         this.state.location.map(item=>{
                             return <option value={item}>{item}</option>
                         })
                     }


                </select>

                <input type = "button" class="btn btn-danger" onClick=
            {this.Delete} value = "DELETE" />

                  </div>
                 
            <div className = "jumbotron">

                Add a new Location 
                <input type = "text" name = "place"id = "place"ref={this.addPlaceRef}  />

                <input type = "button" class="btn btn-primary" onClick = {this.add} value = "ADD" />

                </div>        
              
            <div className = "jumbotron">

                Set Default Location 
                <select id = 'setLocation'>
                    {
                        this.state.location.map(item=>
                            {
                                return <option value={item}>{item}</option>
                            })
                    }
                    </select>
             <Link class="nav-link" to="/">
<input type="button" class="btn btn-success" value="SET" onClick={this.set}></input>

             </Link>
</div>
</form>
</div>


        );


    }
}

export default Settings;