import React from 'react';
import Home from './components/Home';
import {Route} from 'react-router-dom';
import Settings from './components/Settings';
import './App.css';

function App(props)
{
    console.log("App.js");
    return(
        <div>
         {/* <Navbar/> */}

       <div className="container">
           <Route path="/"exact component={Home}/>
           <Route path = "/settings"  exact component = {Settings}/>
     </div>
        </div>
    );
}
export default App; 