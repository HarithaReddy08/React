import React,{ Component } from "react";

export default class Login extends Component{
    constructor(props){
    super(props);

this.state={
    userName:'',
    password:''
}
    }

render()
{

    return(
    
        <div  class="jumbotron row-md-2 col-md-5 hmiddle " >
            <h1>LOGIN</h1>
         <table >
             
  
    <tr>
     <td> <label for="userName">User Name</label></td>
      <td><input type="text" name="userName" id="userName" class='form-control'   aria-describedby="userNameHelp" required/>
      </td> </tr>
     
      
          <tr>
     <td> <label for="password">Password</label></td>
     <td> <input type="text" name="password" id="password" class='form-control'  placeholder="" aria-describedby="passwordHelp" required />
      </td> </tr> 
      <br/> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
      </table>  
      <div class="form-inline hmiddle" >
      <a class="btn btn-primary " href="/Register" role="button">NewUser</a> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
      <a class="btn btn-primary " href="/AfterLogin" role="button">Signup</a>
   
      </div>
      
    </div>
    
    );

}

}