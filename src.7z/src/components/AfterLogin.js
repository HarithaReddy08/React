import React from 'react'
function AfterLogin(props)
{
    return(
        <div>
            <h1>HI , continue your shopping</h1><br/>
          
        </div>
    )
}
export default AfterLogin