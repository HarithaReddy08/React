import React from 'react';

class searchPage extends React.Component
{
render(){
    return(
        <div>
            <div class="form-inline">
                <div>
            <h4>search Item</h4>
            <input type="text" placeholder="Search.."></input><br/>
            <div class="form-inline">
         
            {/* <select  name="date" id="date" class='form-control'  placeholder="" > */}
            <label for="start">From</label>

<input type="date" id="start" />
<label for="end">To</label>

<input type="date" id="end" />
 
        </div>
            </div>
            
            <h4>Filter</h4><br></br>
            <div>
            <br/><font size="3">News Desk</font>&nbsp;&nbsp;
            
            <font size="3">Section</font>&nbsp;&nbsp;
            <font size="3">Type</font>
     
     
            </div>
            
            </div>
            
        </div>
     
    )
}
}
export default searchPage;