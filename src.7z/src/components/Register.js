
import React, { Component } from 'react';

export default class Register extends Component{
    documentData;
    firstNameRef=React.createRef();
lastNameRef=React.createRef();
emailRef=React.createRef();
passwordRef=React.createRef();
confirmPasswordRef=React.createRef();
    constructor(props){
        super(props);
        this.handleChange = this.handleChange.bind(this);
        this.handleFormSubmit = this.handleFormSubmit.bind(this);
this.state={
values:{
    firstName:'',
    lastName:'',
    email:'',
    password:'',
    confirmPassword:''

  
    },errors:
    {
        firstName:[],
        lastName:[],
        email:[],
        password:[],
        confirmPassword:[]
    },
      wasValidated:false  

} ;
    }


// update=(event)=>
// {
//   console.log(event);

//   const newValues={
//  ...this.state.values,
//  [event.target.name]:event.target.value
//   }
//   this.setState(curState=>({...curState,


//   values:newValues
  
// }),
// this.validate
// );

    
    validate=()=>
{
  const errors={
     firstName:[],
     lastName:[],
     email:[],
     password:[],
     confirmPassword:[]
  };
  //check reviewer input for errors and add error messages
if(this.firstNameRef.current.value.length<3)
{
errors.firstName.push('Your name is required');
}
if(this.lastNameRef.current.value.length<3)
{
errors.lastName.push('Last name is required');
}
if(this.emailRef.current.value==='')

{
errors.email.push('email must be valid');
}
if(this.passwordRef.current.value.length<8)
{
errors.password.push('password must have atleast 8 characters');
}
if(this.confirmPasswordRef.current.value===this.passwordRef.current.value )
{
errors.confirmPassword.push('password must be same as given earlier');
}
this.setState({
...this.state,
errors:errors,
wasValidated:true
});
}
isValid=()=>
{
  const {firstName,lastName,email, password,confirmPassword}=this.state.errors;
  return firstName.length===0 && lastName.length===0 && email.length===0 && password.length===0 && confirmPassword.length===0
}
handleChange= (e)=> {
    this.setState({[e.target.name]:e.target.value});
}

handleFormSubmit(e) {
    e.preventDefault()
   localStorage.setItem('document',JSON.stringify(this.state));

    }
    componentDidMount(){
    this.documentData = JSON.parse(localStorage.getItem('document'));
 
    if (localStorage.getItem('document')) {
        this.setState({
            firstName: this.documentData.firstName,
           lastName: this.documentData.lastName,
           email: this.documentData.email,
           password: this.documentData.password,
           confirmPassword: this.documentData.confirmPassword,
    })
} else {
    this.setState({
        firstName: '',
        lastName: '',
        email: '',
        password:'',
        confirmPassword:''
    })
}
}


    render()
    {
return(
        <div class="jumbotron align-center  col-md-5 hmiddle">
            <form class={`form-horizontal ${this.state.wasValidated? 'was-validated':''}`} onSubmit={this.handleFormSubmit} noValidate>
            <h1>Registration Form</h1>
         <table>
             <tr>
                <td>
                  <label for="firstName">First Name</label></td>
                <td>

               <input type="text" name="firstName" class={`form-control ${this.state.errors.firstName.length<3? `is-valid`:`is-invalid`}`} aria-describedby="firstNameHelp" ref={this.firstNameRef} value={this.firstName} onChange={this.handleChange}/>
               <small id="helpId" class="text-muted">Please enter the full name</small>
         </td> 
         <div class="invalid-feedback">
             {this.state.errors.firstName.map(error=><div>{error}</div>)}
         </div>
         
         </tr><br/>
      <tr>
                 <td>
      <label for="LastName">Last Name</label></td>
      <td>
      
      <input type="text" name="lastName" class={`form-control ${this.state.errors.lastName.length===0? `is-valid`:`is-invalid`}`} aria-describedby="lastNameHelp" ref={this.lastNameRef} value={this.lastName} onChange={this.handleChange}/>
      </td> <small id="helpId" class="text-muted">Please enter the last name</small><div class="invalid-feedback">
             {this.state.errors.lastName.map(error=><div>{error}</div>)}
         </div> </tr><br/>
      <tr>
                 <td>
      <label for="email">Email</label></td>
      <td>
      
      <input type="email" name="e
                                                                                                                                                                                                                                                                                                                                                                                                    mail" class={`form-control ${this.state.errors.email.length===0? `is-valid`:`is-invalid`}`} aria-describedby="emailHelp" ref={this.emailRef} value={this.email}   onChange={this.handleChange}/>
      </td> <small id="helpId" class="text-muted">Please enter the email</small><div class="invalid-feedback">
             {this.state.errors.email.map(error=><div>{error}</div>)}
         </div> </tr><br/>
      <tr>
                 <td>
      <label for="password">Password</label></td>
      <td>
      
      <input type="password" name="password" class={`form-control ${this.state.errors.password.length===0? `is-valid`:`is-invalid`}`}aria-describedby="passwordHelp"  ref={this.passwordRef} value={this.password} onChange={this.handleChange} />
      </td> <small id="helpId" class="text-muted">Please enter the password</small><div class="invalid-feedback">
             {this.state.errors.password.map(error=><div>{error}</div>)}
         </div> </tr><br/>
      <tr>
                 <td>
      <label for="confirmPassword">confirm Password</label></td>
      <td>
      
      <input type="password" name="confirmPassword" class={`form-control ${this.state.errors.confirmPassword.length===0? `is-valid`:`is-invalid`}`} aria-describedby="confirmPasswordHelp" value={this.confirmPassword} ref={this.confirmPasswordRef}   onChange={this.handleChange}/>    
      </td><small id="helpId" class="text-muted">Please re-enter the password</small> <div class="invalid-feedback">
             {this.state.errors.firstName.map(error=><div>{error}</div>)}
         </div> </tr>
      </table><br/>
      <a class="btn btn-danger " href="/" role="button">Cancel</a> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
     
      <button class="btn btn-primary" type="submit">Register</button>
      </form>
        </div>
    );
}}

