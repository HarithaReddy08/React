import React from 'react';
import {Route} from 'react-router-dom';

import searchPage from '../src/components/searchPage'

function App() {
  return (
    <div className="App">
   <Route path="/" exact component={searchPage}/>
    </div>
  );
}

export default App;
