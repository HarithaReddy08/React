import React from 'react';
import {Route} from 'react-router-dom';

import searchPage from '../src/components/searchPage'
import searchResults from '../src/components/searchResults'
function App() {
  return (
    <div className="App">
   <Route path="/" exact component={searchPage}/>

   <Route path="/searchDetails" exact component={searchResults}/> 
    </div>
  );
}

export default App;
