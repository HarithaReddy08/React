import axios from 'axios';

export default class searchService {

    static baseURL = "https://developer.nytimes.com";

   

    static getSearchDetails(){

       
        return axios.get(`${this.baseURL}/article_search_v2.json#/README`)

        .then(function(response){

            
            return response.data;
        })
        .catch(function(error){

            console.log(error.message);
            throw error;

        })
    }





}