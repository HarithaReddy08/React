import React from 'react';
import { Link } from 'react-router-dom';

class searchPage extends React.Component
{
render(){
    return(
       <div>
        <div className="container jumbotron">
        <form className="form-inline">
          <div className="">   
<label id="search"><b>Search</b></label><br/>  
            <input type="text" id="search" className="form-control"  placeholder="Search.."></input><br/>
            <table>
                <tr>
                    <td>
                        From
                    </td>
                    <td>
                        To
                    </td>
                </tr>
                <tr>
                    <td>
                        <input type="date" className="form-control"></input>
                    </td>
                    <td>
                        <input type="date" className="form-control"></input>
                    </td>
                </tr>
            </table>
            </div> 
            <div className="her">
                <label ><b>Filter</b></label><br/>
                <table>
                    <tr>
                        <td>News Desk</td>
                        <td>Section</td>
                        <td>type</td>
                    </tr>
                    <tr>
                        <td>
                        <select  name="savedLocations" id="savedLocations" class='form-control'  placeholder="" aria-describedby="savedLocationsHelp" ref={this.savedLocationRef} onChange={this.update}>
      <option>select Option:</option>
      
      </select>
                        </td>
                        <td>
                        <select  name="savedLocations" id="savedLocations" class='form-control'  placeholder="" aria-describedby="savedLocationsHelp" ref={this.savedLocationRef} onChange={this.update}>
      <option>select Option:</option>
    
      </select>
                        </td>
                        <td>
                        <select  name="savedLocations" id="savedLocations" class='form-control'  placeholder="" aria-describedby="savedLocationsHelp" ref={this.savedLocationRef} onChange={this.update}>
      <option>select Option:</option>

      </select>
                        </td>
                    </tr>
                    <Link to={`searchResults`}>
                    
                    <button className="btn btn-primary">Search</button> </Link>
                </table>
                
            </div>
          
            
            </form>
           
        </div> 
        
     
        <h1>SEARCH RESULTS</h1>
        </div>
    )
}
}
export default searchPage;