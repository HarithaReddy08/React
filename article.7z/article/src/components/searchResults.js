import React,{Component} from 'react'
const SEARCHDETAILS_FETCHING='SEARCHDETAILS_FETCHING';
const SEARCHDETAILS_FETCHED='SEARCHDETAILS_FETCHED';
const SEARCHDETAILS_FETCH_FAILED='SEARCHDETAILS_FETCH_FAILED';
class searchResults extends Component
{
    state={
status:null,
error:null
    }
render()
{
    const {error,status}=this.setState
    let el=null;

    switch(status)
    {
        case SEARCHDETAILS_FETCHING:
            el=(

                <h1>
                    PLease wait details are fetching!!!!!!!
                    </h1>
            )
            break;

            case SEARCHDETAILS_FETCHED:
                el=(
                   <div>
                       
                   </div>
                )
                break;
            case SEARCHDETAILS_FETCH_FAILED:
                el=(
               <font size="5" color="red">
                        Sorry!!!!! fetching failed
                        </font>
                )
    }

    return(

        <div>
{el}
        </div>
    )
}

componentDidMount()
{
    this.setState({
status:SEARCHDETAILS_FETCHING
    })
}
}
export default searchResults;