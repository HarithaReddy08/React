import React from 'react';
import Login from './components/Login'
import './App.css';
import Home from '../src/components/Home'
import Register from '../src/components/Register'
import { Route } from 'react-router-dom';

function App() {
  return (
    <div className="App">
      <Route path="/" exact component={Home}/>
<Route path="/Login" exact component={Login}/>
<Route path="/Register" exact component={Register}/>
    </div>
  );
}

export default App;
