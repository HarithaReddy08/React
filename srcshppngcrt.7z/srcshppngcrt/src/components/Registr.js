import React, { Component } from 'react';

export default class Register extends Component{
  
    constructor(props){
        super(props);
      
state={
  value:{ firstName:'',
    lastName:'',
    email:'',
    password:'',
    confirmPassword:''},
errors:
    {
        firstName:[],
        lastName:[],
        email:[],
        password:[],
        confirmPassword:[]
    },
      wasValidated:false  
  };
  firstNameRef=React.createRef();
  lastNameRef=React.createRef();
  emailRef=React.createRef();
  passwordRef=React.createRef();
  confirmPasswordRef=React.createRef();


  update=(event)=>
  {
    console.log(event);
    // event.target.value
    // event.target.name
    const newValues={
   ...this.state.values,
   [event.target.name]:event.target.value
    }
    this.setState(curState=>({...curState,
  
  
    values:newValues
    
  }),
  this.validate
  );
  
  
  }


   validate=()=>
   {
     const errors={
        firstName:[],
        lastName:[],
        email:[],
        password:[],
        confirmPassword:[]
     }
     //check reviewer input for errors and add error messages
if(this.firstNameRef.current.value==='')
{
errors.firstName.push('Your name is required');
}
if(this.lastNameRef.current.value==='')
{
errors.lastName.push('Last name is required');
}
if(this.emailRef.current.value.length=== "@gmail.com")

{
errors.email.push('email must be valid');
}
if(this.password.current.value.length<20 || this.password.current.value==="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}")
{
errors.text.push('review must have atleast 20 characters');
}
this.setState({
  ...this.state,
  errors:errors,
  wasValidated:true
});
   
   isValid=()=>
   {
     const {firstName,lastName,email, password,confirmPassword}=this.state.errors;
     return firstName.length===0 && lastName.length===0 && email.length===0 && password.length===0 && confirmPassword.length===0
   }
    render()
    {
return(
    
                

        <div class="jumbotron align-center  col-md-5 hmiddle">
            <form className={`form-horizontal ${this.state.wasValidated? 'was-validated':''}`} onSubmit={this.handleFormSubmit} onChange="">
            <h1>Registration Form</h1>
         <table>
             <tr>
                 <td>
      <label for="firstName">First Name</label></td>
      <td>

      <input type="text" name="firstName"  class={`form-control ${this.state.errors.firstName.length===0? `is-valid`:`is-invalid`}`} value={this.state.firstname} onChange={this.handleChange}/>
      </td> <small id="helpId" class="text-muted">Please enter the first name</small><div className="invalid-feedback">
  
  {
    this.state.errors.firstName.map(error=><div>{error}</div>)
  }
  </div></tr><br/>
      <tr>
                 <td>
      <label for="LastName">Last Name</label></td>
      <td>
      
      <input type="text" name="lastName" class={`form-control ${this.state.errors.lastName.length===0? `is-valid`:`is-invalid`}`} value={this.state.lastName} onChange={this.handleChange}/>
      </td><small id="helpId" class="text-muted">Please enter the last name</small><div className="invalid-feedback">
  
  {
    this.state.errors.lastName.map(error=><div>{error}</div>)
  }
  </div> </tr><br/>
      <tr>
                 <td>
      <label for="email">Email</label></td>
      <td>
      
      <input type="text" name="email" class={`form-control ${this.state.errors.email.length===0? `is-valid`:`is-invalid`}`} value={this.state.email}   onChange={this.handleChange}/>
      </td><small id="helpId" class="text-muted">Please enter Email</small><div className="invalid-feedback">
  
  {
    this.state.errors.email.map(error=><div>{error}</div>)
  }
  </div> </tr><br/>
      <tr>
                 <td>
      <label for="password">Password</label></td>
      <td>
      
      <input type="password" name="password"class={`form-control ${this.state.errors.password.length===0? `is-valid`:`is-invalid`}`}  value={this.state.password} onChange={this.handleChange} />
      </td><small id="helpId" class="text-muted">Please enter password</small><div className="invalid-feedback">
  
  {
    this.state.errors.password.map(error=><div>{error}</div>)
  }
  </div> </tr><br/>
      <tr>
                 <td>
      <label for="password">confirm Password</label></td>
      <td>
      
      <input type="password" name="confirmPassword" id="confirmPassword"class={`form-control ${this.state.errors.confirmPassword.length===0? `is-valid`:`is-invalid`}`} value={this.state.confirmPassword}  onChange={this.handleChange}/>    
      </td><small id="helpId" class="text-muted">Please enter password again</small><div className="invalid-feedback">
  
  {
    this.state.errors.confirmPassword.map(error=><div>{error}</div>)
  }
  </div> </tr>
      </table><br/>
      <a class="btn btn-danger " href="/" role="button">Cancel</a> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
     
      <button class="btn btn-primary" type="submit">Register</button>
      </form>
        </div>
    );
}
}

