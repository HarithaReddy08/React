import React, { Component } from 'react';

export default class Register extends Component{
    documentData;
    constructor(props){
        super(props);
        this.handleChange = this.handleChange.bind(this);
        this.handleFormSubmit = this.handleFormSubmit.bind(this);
this.state={
    firstName:'',
    lastName:'',
    email:'',
    password:'',
    confirmPassword:''
}}
handleChange= (e)=> {
    this.setState({[e.target.name]:e.target.value});
}
handleFormSubmit(e) {
    e.preventDefault()
   localStorage.setItem('document',JSON.stringify(this.state));

    }
    componentDidMount(){
    this.documentData = JSON.parse(localStorage.getItem('document'));
 
    if (localStorage.getItem('document')) {
        this.setState({
            firstName: this.documentData.firstName,
           lastName: this.documentData.lastName,
           email: this.documentData.email,
           password: this.documentData.password,
           confirmPassword: this.documentData.confirmPassword,
    })
} else {
    this.setState({
        firstName: '',
        lastName: '',
        email: '',
        password:'',
        confirmPassword:''
    })
}
}
    render()
    {
return(
        <div class="jumbotron align-center  col-md-5 hmiddle">
            <form onSubmit={this.handleFormSubmit}>
            <h1>Registration Form</h1>
         <table>
             <tr>
                 <td>
      <label for="firstName">First Name</label></td>
      <td>

      <input type="text" name="firstName"  class='form-control' value={this.state.firstname} onChange={this.handleChange}/>
      </td> </tr><br/>
      <tr>
                 <td>
      <label for="LastName">Last Name</label></td>
      <td>
      
      <input type="text" name="lastName" class='form-control' value={this.state.lastName} onChange={this.handleChange}/>
      </td> </tr><br/>
      <tr>
                 <td>
      <label for="email">Email</label></td>
      <td>
      
      <input type="text" name="Email"  class='form-control' value={this.state.email}   onChange={this.handleChange}/>
      </td> </tr><br/>
      <tr>
                 <td>
      <label for="password">Password</label></td>
      <td>
      
      <input type="text" name="password" class='form-control'  value={this.state.password} onChange={this.handleChange} />
      </td> </tr><br/>
      <tr>
                 <td>
      <label for="password">confirm Password</label></td>
      <td>
      
      <input type="text" name="password" id="confirmPassword" class='form-control' value={this.state.confirmPassword}  onChange={this.handleChange}/>    
      </td> </tr>
      </table><br/>
      <a class="btn btn-danger " href="/" role="button">Cancel</a> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
     
      <button class="btn btn-primary" type="submit">Register</button>
      </form>
        </div>
    );
}}
